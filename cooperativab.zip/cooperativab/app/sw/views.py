from django.shortcuts import render, HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from app.modelo.models import Cliente
from app.sw.serializable import ClienteSerializable

class ListaCliente(APIView):
	def get(self, request):
		lista = Cliente.objects.all() #lista de objetos normales
		objetoSerializable = ClienteSerializable(lista, many = True)
		return Response(objetoSerializable.data)

class genero(APIView):
	def get(self, request):
		if request.GET["genero"] == "f":
			lista = Cliente.objects.all().filter(genero="f") #lista de objetos normales
			objetoSerializable = ClienteSerializable(lista, many = True)
			return Response(objetoSerializable.data)
		if request.GET["genero"] == "m": 
			lista = Cliente.objects.all().filter(genero="m") #lista de objetos normales
			objetoSerializable = ClienteSerializable(lista, many = True)
			return Response(objetoSerializable.data)
		else:
			return HttpResponse("El genero que ingreso no existe")

class cedula(APIView):
	def get(self, request):
		dni = request.GET["cedula"]
		lista = Cliente.objects.all().filter(cedula=dni) #lista de objetos normales

		objetoSerializable = ClienteSerializable(lista, many = True)

		return Response(objetoSerializable.data)
	
class agregar(APIView):
	def get(self, request):
		dni = request.GET["cedula"]
		lista = Cliente.objects.all().filter(cedula=dni) #lista de objetos normales
		objetoSerializable = ClienteSerializable(lista, many = True)
		return Response(objetoSerializable.data)



