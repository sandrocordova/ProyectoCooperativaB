from django.urls import path

from . import views

urlpatterns = [
	path("papiSandro", views.ListaCliente.as_view()),
	path("cedula", views.cedula.as_view()),
	path("genero", views.genero.as_view())
]