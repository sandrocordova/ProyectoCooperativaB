from django.apps import AppConfig


class SwConfig(AppConfig):
    name = 'sw'
