from django.db import models

# Create your models here.
class Cliente(models.Model):
	idCliente = models.CharField(max_length = 10)
	cedula = models.CharField(max_length = 10)
	nombres = models.CharField(max_length = 25)
	apellidos = models.CharField(max_length = 25)
	listaGenero = (
		('f', 'Femenino'),
		('m', 'Masculino')
		)
	genero = models.CharField(max_length = 15, choices = listaGenero)
	listaEstado = (
		('soltero', 'Soltero'),
		('casado', 'Casado'),
		('viudo', 'Viudo'),
		('divorciado', 'Divorciado')
		)
	estadoCivil = models.CharField(max_length = 15, choices = listaEstado)
	fechaNacimiento = models.DateField(unique_for_date= '', max_length = 50)
	correo = models.CharField(max_length = 100)
	telefono = models.CharField(max_length = 10)
	estado = models.BooleanField(default = True)


class Cuenta(models.Model):
	idCuenta = models.CharField(max_length=10)
	numeroCuenta = models.CharField(max_length = 10)
	estado = models.BooleanField(default = True)
	fechaCreacion = models.DateTimeField(auto_now = True)
	saldo = models.DecimalField(max_digits=50, decimal_places = 2, default = '5.00')
	listaCuenta = (
		('ahorro', 'Ahorro'),
		('corriente', 'Corriente')
		)
	tipoCuenta = models.CharField(max_length = 10, choices = listaCuenta)


class Transaccion(models.Model):
	idTrans = models.CharField(max_length=10)
	fecha = models.DateTimeField(auto_now = True)
	cuentaDestino = models.CharField(max_length = 10)
	cantidad = models.DecimalField(max_digits=50, decimal_places = 2)
	tipoTrans = models.CharField(max_length=100);
