from django.contrib import admin

from .models import Cliente
from .models import Cuenta
from .models import Transaccion

class AdminCliente(admin.ModelAdmin):
	list_display= ["cedula","nombres","apellidos","genero", "estadoCivil","fechaNacimiento","correo","telefono"]
	#list_editable = ["apellidos","nombres"]
	#list_filter = ["genero"]
	#search_fields = ["cedula"]

	class Meta: 
		model = Cliente

admin.site.register(Cliente, AdminCliente)
	
class AdminCuenta(admin.ModelAdmin):
	list_display= ["numeroCuenta", "estado", "tipoCuenta","fechaCreacion","saldo"]

	class Meta: 
		model = Cuenta

admin.site.register(Cuenta, AdminCuenta)

class AdminTransaccion(admin.ModelAdmin):
	list_display= ["fecha","cuentaDestino","cantidad","tipoTrans"]
	#list_editable = ["apellidos","nombres"]
	#list_filter = ["genero"]
	#search_fields = ["cedula"]

	class Meta: 
		model = Transaccion

admin.site.register(Transaccion, AdminTransaccion)
