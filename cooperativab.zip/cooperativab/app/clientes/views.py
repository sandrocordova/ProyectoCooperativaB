from django.shortcuts import render, redirect, render_to_response, HttpResponseRedirect, HttpResponse
from django.contrib import messages
from django.http import HttpResponse
from django.urls import reverse
import time
from django.contrib.auth.decorators import login_required
#import webbrowser
from rest_framework.views import APIView
from .form import FormularioCliente, FormularioCuenta
from app.modelo.models import Cliente, Cuenta, Transaccion
from decimal import Decimal

#PDF
import io
from django.http import FileResponse
from reportlab.pdfgen import canvas

import csv
from weasyprint import HTML, CSS
from django.template.loader import get_template,render_to_string
from django.http import HttpResponse
from weasyprint.fonts import FontConfiguration


# Create your views here.
def home_cliente(request):
	return render(request, 'cliente/home_clientes.html')

def  header(request):
	return render(request, 'header.html')

@login_required
def  lista(request):
	usuario = request.user
	if usuario.has_perm('modelo.add_cliente'):
		if request.method == "POST":

			try:
		  		dni = request.POST.get("cuenta")
		  		tamaño = len(dni)
			except Cuenta.DoesNotExist:
		  		dni = None
		  	
			if tamaño>0: 
				listaClientes = Cliente.objects.all().filter(estado=True, cedula = dni)
				listaCuentas = Cuenta.objects.all().filter(numeroCuenta=dni)
				context={
					'lista':listaClientes,
					'lista2':listaCuentas,
				}
				return render(request, 'cliente/principal_cliente.html', context)
			else:
				listaClientes = Cliente.objects.all().filter(estado=True).order_by("apellidos")[:5]
				listaCuentas = Cuenta.objects.all()
				context={
					'lista':listaClientes,
					'lista2':listaCuentas,
				}
				return render(request, 'cliente/principal_cliente.html', context)

		return render(request, "cliente/buscar.html")
	context={
		'mensaje':'mensaje',
	}	
	return render(request, 'login/acceso_prohibido.html', context)

@login_required
def  primerMensaje(request):
	#httpresponse envía un mensaje
	return HttpResponse("Primer Mensaje")

@login_required
def papeleta(request):
	try:
  		persona = Cuenta.objects.get(numeroCuenta=request.POST.get("cuenta"))
	except Cuenta.DoesNotExist:
  		persona = None

	
	cuenta = request.POST.get("cuenta")
	if request.method == 'POST':
		if persona:
			cuenta2 = Cuenta.objects.get(numeroCuenta=cuenta)
			tipo = cuenta2.tipoCuenta
			saldo = cuenta2.saldo
			lista = Transaccion.objects.all().filter(cuentaDestino=cuenta)
			html_template = render_to_string('./../templates/pdf/papeleta.html',locals())
			response = HttpResponse(content_type='application/pdf')
			pdf_file = HTML(string=html_template).write_pdf()
			response = HttpResponse(pdf_file, content_type='application/pdf')
			response['Content-Disposition'] = 'filename="home_page.pdf"'
			return response
		else:
			context = {
			'mensaje':'La cuenta ingresada no existe',
			}
			return render(request, "transaccion/papeleta.html", context)

	return render(request, "transaccion/papeleta.html")

@login_required
def depositar(request):
	dni = request.POST.get("numeroCuenta")

	if request.method == 'POST':

		try:
	  		persona = Cuenta.objects.get(numeroCuenta=request.POST.get("numeroCuenta"))
		except Cuenta.DoesNotExist:
	  		persona = None
  		
		if persona:
			cuenta = Cuenta.objects.get(numeroCuenta=dni)
			cliente = Cliente.objects.get(cedula=dni)
			transaccion = Transaccion()
			saldoAnterior = cuenta.saldo
			valor = Decimal(request.POST.get("nuevoSaldo"))
			nuevoSaldo = valor+saldoAnterior
			cuenta.saldo = nuevoSaldo
			cuenta.save()
			transaccion.idTrans = dni
			transaccion.fecha = time.strftime("%x %X")
			transaccion.cuentaDestino = dni
			transaccion.cantidad = valor
			transaccion.tipoTrans = "Depósito"
			transaccion.save()

			context = {
				'dni':dni,
				'nuevoSaldo': nuevoSaldo,
				'saldoAnterior': saldoAnterior,
				'valor': valor,
				'nombre': cliente.nombres,
				'apellido': cliente.apellidos,
				'tipo': cuenta.tipoCuenta
			}
			hora = time.strftime("%x %X")

			html_template = render_to_string('./../templates/pdf/comprobanteDeposito.html',locals())
			response = HttpResponse(content_type='application/pdf')
			pdf_file = HTML(string=html_template).write_pdf()
			response = HttpResponse(pdf_file, content_type='application/pdf')
			response['Content-Disposition'] = 'filename="home_page.pdf"'

			return response
		else:
			context = {
				'mensaje':'La cuenta del receptor no existe',
			}
			return render(request, "transaccion/deposito.html", context)
	context = {
				'mensaje':'',
			}	
	return render(request, "transaccion/deposito.html", context)

@login_required
def transferencia(request):

	dni = request.POST.get("numeroCuentaSale")
	dni2 = request.POST.get("numeroCuentaEntra")
	try:
	  	personaEntra = Cuenta.objects.get(numeroCuenta=dni2)
	except Cuenta.DoesNotExist:
		personaEntra = None

	if request.method == 'POST':
		try:
	  		personaSale = Cuenta.objects.get(numeroCuenta=dni)
		except Cuenta.DoesNotExist:
	  		personaSale = None

		if personaSale:
			if personaEntra:
				cuentaSale = Cuenta.objects.get(numeroCuenta=dni)
				cuentaEntra = Cuenta.objects.get(numeroCuenta=dni2)
				clienteSale = Cliente.objects.get(cedula=dni)
				clienteEntra = Cliente.objects.get(cedula=dni2)
				transaccionSale = Transaccion()
				transaccionEntra = Transaccion()
				valor = Decimal(request.POST.get("nuevoSaldo"))
				nuevoSaldoSale = cuentaSale.saldo-valor
				nuevoSaldoEntra = cuentaEntra.saldo+valor
				if nuevoSaldoSale>0:
					cuentaSale.saldo = nuevoSaldoSale
					cuentaSale.save()
					cuentaEntra.saldo = nuevoSaldoEntra
					cuentaEntra.save()
					transaccionSale.idTrans = dni
					transaccionSale.fecha = time.strftime("%x %X")
					transaccionSale.cuentaDestino = dni
					transaccionSale.cantidad = valor
					transaccionSale.tipoTrans = "Retiro"
					transaccionSale.save()

					transaccionEntra.idTrans = dni2
					transaccionEntra.fecha = time.strftime("%x %X")
					transaccionEntra.cuentaDestino = dni2
					transaccionEntra.cantidad = valor
					transaccionEntra.tipoTrans = "Depósito"
					transaccionEntra.save()

					context= {
						'dni':dni,
						'dni2':dni2,
						'valor': valor,
						'tipo': cuentaSale.tipoCuenta,
						'nombre': clienteSale.nombres,
						'apellido': clienteSale.apellidos,
					}
					hora = time.strftime("%x %X")
					html_template = render_to_string('./../templates/pdf/comprobanteTransferencia.html',locals())
					response = HttpResponse(content_type='application/pdf')
					pdf_file = HTML(string=html_template).write_pdf()
					response = HttpResponse(pdf_file, content_type='application/pdf')
					response['Content-Disposition'] = 'filename="home_page.pdf"'

					return response
				else:
					context = {
					'mensaje':'Saldo del depositante insuficiente, saldo actual de la cuenta: $',
					'saldo': cuentaSale.saldo,
					}
			else:
				context = {
				'mensaje':'La cuenta del receptor no existe',
			}
		else:
			context = {
				'mensaje':'La cuenta del depositante no existe',
			}


	else:
		context = {
				'mensaje':'',
			}		

	return render(request, "transaccion/transferencia.html", context)

@login_required
def retirar(request):
	dni = request.POST.get("numeroCuenta")

	if request.method == 'POST':
		try:
	  		persona = Cuenta.objects.get(numeroCuenta=dni)
		except Cuenta.DoesNotExist:
	  		persona = None

		if persona:
			cuenta = Cuenta.objects.get(numeroCuenta=dni)
			cliente = Cliente.objects.get(cedula=dni)
			transaccion = Transaccion()
			saldoAnterior = cuenta.saldo
			valor = Decimal(request.POST.get("nuevoSaldo"))
			nuevoSaldo = saldoAnterior-valor
			if nuevoSaldo>0:

				cuenta.saldo = nuevoSaldo
				cuenta.save()
				transaccion.idTrans = dni
				transaccion.fecha = time.strftime("%x %X")
				transaccion.cuentaDestino = dni
				transaccion.cantidad = valor
				transaccion.tipoTrans = "Retiro"
				transaccion.save()

				context = {
				'dni':dni,
				'nuevoSaldo': nuevoSaldo,
				'saldoAnterior': saldoAnterior,
				'valor': valor,
				'nombre': cliente.nombres,
				'apellido': cliente.apellidos,
				'tipo': cuenta.tipoCuenta
				}

				hora = time.strftime("%x %X")

				html_template = render_to_string('./../templates/pdf/comprobanteRetiro.html',locals())
				response = HttpResponse(content_type='application/pdf')
				pdf_file = HTML(string=html_template).write_pdf()
				response = HttpResponse(pdf_file, content_type='application/pdf')
				response['Content-Disposition'] = 'filename="home_page.pdf"'

				return response
			else:
				context = {
				'mensaje':'Saldo insuficiente, saldo actual de la cuenta: $'+saldoAnterior,
			}
		else:
			context = {
				'mensaje':'La cuenta ingresada no existe',
			}
	else:
		context = {
				'mensaje':'',
			}		

	return render(request, "transaccion/retirar.html", context)

@login_required
def modificar(request):
	usuario = request.user
	if usuario.has_perm('modelo.change_cliente'):

		dni = request.GET["cedula"]
		cliente = Cliente.objects.get(cedula=dni)
		cuenta = Cuenta.objects.get(numeroCuenta=dni)

		if request.method == 'POST':
			formulario = FormularioCliente(request.POST)
			cliente.nombres = request.POST.get('nombres')
			cliente.apellidos = request.POST.get('apellidos')
			cliente.genero = request.POST.get('genero')
			cliente.estadoCivil = request.POST.get('estadoCivil')
			cliente.correo = request.POST.get('correo')
			cliente.telefono = request.POST.get('telefono')
			cliente.save()
			cuenta.tipoCuenta = request.POST.get('tipoCuenta')
			cuenta.save()
			context = {
						'mensaje':'La cuenta dde modificó correctamente',
						'confirmacion':'1',
						}
			return redirect(lista)
		 
		context = {
			'cedula': cliente.cedula,
			'nombres':cliente.nombres,
			'apellidos':cliente.apellidos,
			'genero':cliente.genero,
			'estadoCivil': cliente.estadoCivil,
			'fechaNacimiento': cliente.fechaNacimiento,
			'correo':cliente.correo,
			'telefono':cliente.telefono,
			'tipoCuenta': cuenta.tipoCuenta,
		}		

		return render(request, "cliente/modificar_cliente.html", context)

	context={
		'mensaje':'mensaje',
	}	
	return render(request, 'login/acceso_prohibido.html', context)

@login_required	
def  crear(request):
	formulario = FormularioCliente(request.POST)
	formulario2 = FormularioCuenta(request.POST)
	context = {
	'f':formulario,
	'f2':formulario2,
	'mensaje':'',
	}
	if request.method == "POST":
		aux = request.POST.get('tipoCuenta')
		if formulario.is_valid():
			datos = formulario.cleaned_data
			tamaño = len(datos.get('cedula'))
			if  tamaño == 10 and len(datos.get('telefono')) >= 7:
				
				try:
			  		persona = Cliente.objects.get(cedula=datos.get('cedula'))
				except Cliente.DoesNotExist:
			  		persona = None

				if persona:
					context = {
						'f':formulario,
						'f2':formulario2,
						'mensaje':'La cuenta ingresada ya existe',
						'confirmacion':'1',
						}
					return render(request, "cliente/crear_cliente.html", context)
				else:
					print("Entro al-------------------------")
					cliente = Cliente()
					cliente.idCliente = datos.get('cedula')
					cliente.cedula = datos.get('cedula')
					cliente.nombres = datos.get('nombres')
					cliente.apellidos = datos.get('apellidos')
					cliente.genero = datos.get('genero')
					cliente.estadoCivil = datos.get('estadoCivil')
					cliente.fechaNacimiento = datos.get('fechaNacimiento')
					cliente.correo = datos.get('correo')
					cliente.telefono = datos.get('telefono')
					cliente.save()
					cuenta = Cuenta()
					cuenta.idCuenta = datos.get('cedula')
					cuenta.numeroCuenta = datos.get('cedula')
					cuenta.tipoCuenta = request.POST.get('tipoCuenta')
					cuenta.save()
					context = {
						'mensaje':'Cuenta creada',
						'confirmacion':'1',
						}
					return redirect(reverse(lista))
			context = {
						'mensaje':'Por favor verificar número de cedula o teléfono',
						'confirmacion':'1',
						}
			return render(request, "cliente/crear_cliente.html", context)
	
	return render(request, "cliente/crear_cliente.html", context)

@login_required
def  crearCuenta(request):
	formulario = FormularioCuenta(request.POST)
	if request.method == "POST":
		if formulario.is_valid():
			datos = formulario.cleaned_data
			cuenta = Cuenta()
			cuenta.idCuenta = datos.get('cedula')
			cuenta.numeroCuenta = datos.get('cedula')
			cuenta.usuario = datos.get('usuario')
			cuenta.contrasenia = datos.get('contrasenia')
			cuenta.tipoCuenta = datos.get('tipoCuenta')
			cuenta.save()
			return redirect(" ")

	context = {
	'f':formulario,
	}#utilizamos render porque ya no quiero mostrar un mensaje
	return render(request, "cliente/crear_cuenta.html", context)

@login_required
def eliminar(request):
	dni = request.GET["cedula"]
	cliente = Cliente.objects.get(cedula=dni)
	cliente.estado=False
	cliente.save()
	return redirect(lista)

