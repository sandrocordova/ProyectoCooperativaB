from django import forms
from app.modelo.models import Cliente, Cuenta

class FormularioCliente(forms.ModelForm):
	""""
	PAra hacer el mapeo se utiliza meta"""
	class Meta: 
		model = Cliente
		fields = ["cedula","nombres","apellidos","genero","estadoCivil","fechaNacimiento","correo","telefono"]

class FormularioCuenta(forms.ModelForm):
	class Meta:
		model = Cuenta
		fields = ["tipoCuenta"]