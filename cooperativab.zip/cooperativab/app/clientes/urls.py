#el controlador es el view
from django.urls import path

from . import views

urlpatterns = [
	path("", views.home_cliente, name="principal"),
	path("lista", views.lista, name="lista"),
	path("primerMensaje", views.primerMensaje),
	path("crear", views.crear),
	path("modificar", views.modificar),
	path("depositar", views.depositar, name="depositar"),
	path("retirar", views.retirar),
	path("transferencia", views.transferencia),
	path("header", views.header),
	path("papeleta", views.papeleta, name = "papeleta"),
	path("eliminar", views.eliminar)
]