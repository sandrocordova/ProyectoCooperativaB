from django.shortcuts import render, render_to_response

from app.clientes.form import FormularioCliente, FormularioCuenta
from app.modelo.models import Cliente, Cuenta

def homePage(request):
	return render_to_response('home_page.html')
